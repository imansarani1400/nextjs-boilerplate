import { Low, JSONFile } from 'lowdb';
import path from 'path';

const file = path.join(process.cwd(), 'db.json');
const adapter = new JSONFile(file);
const db = new Low(adapter);

export default async function handler(req, res) {
  await db.read();
  db.data ||= { votes: { builder: 0, defidj: 0, creator: 0, lurker: 0 } };

  if (req.method === 'POST') {
    const { identity } = req.body;
    if (!db.data.votes[identity]) return res.status(400).json({ error: "Invalid identity" });
    db.data.votes[identity]++;
    await db.write();
    return res.json(db.data.votes);
  }

  return res.json(db.data.votes);
}