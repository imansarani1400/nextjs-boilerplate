import { useState, useEffect } from 'react';

export default function Home() {
  const [votes, setVotes] = useState({});
  const [picked, setPicked] = useState(null);

  useEffect(() => {
    fetch('/api/vote')
      .then(res => res.json())
      .then(data => setVotes(data));
  }, []);

  const handleClick = (id) => {
    setPicked(id);
    fetch('/api/vote', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ identity: id })
    })
    .then(res => res.json())
    .then(data => setVotes(data));
  };

  const total = Object.values(votes).reduce((a,b)=>a+b, 0) || 1;

  return (
    <div style={{ fontFamily:'sans-serif', textAlign:'center', padding:'2rem' }}>
      <h1>🎭 Who are you in Web3?</h1>
      {['builder','defidj','creator','lurker'].map(id => (
        <button
          key={id}
          onClick={() => handleClick(id)}
          style={{ margin:'0.5rem', padding:'1rem 2rem',
                   background: picked===id ? '#4CAF50' : '#EEE' }}
        >
          {
            {
              builder: '🧙‍♂️ Builder',
              defidj: '🤑 DeFi DJ',
              creator: '🎨 Creator',
              lurker: '🤖 Lurker'
            }[id]
          }
        </button>
      ))}
      {picked && (
        <div style={{ marginTop:'2rem' }}>
          <h2>You chose: {picked}</h2>
          <p>Stats:</p>
          <ul style={{ listStyle: 'none' }}>
            {Object.entries(votes).map(([id, count]) => (
              <li key={id}>
                {id}: {((count/total)*100).toFixed(1)}% ({count} votes)
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}